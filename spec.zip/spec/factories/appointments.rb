FactoryBot.define do
  factory :appointment do
    appointment_date { '2021-07-12 07:15:29' }
    doctor { nil }
  end
end
