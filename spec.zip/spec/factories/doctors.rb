FactoryBot.define do
  factory :doctor do
    name { 'MyString' }
    specialization { 'MyString' }
    experience { 'MyString' }
    image { 'MyString' }
  end
end
